<?PHP

/**
*
*	Framework de Grafico - Constantes
*
*	Data de Criacao: 19/01/2004
*	Ultima Atualizacao: 19/01/2004
*	Modulo: RelatorioConst.php
*       Framework de graficos
*
*	Copyright (C) por APOENA Solucoes em Software Livre
*	http://www.apoenasoftwarelivre.com.br
*
*       @author     Claudimir Zavalik (claudimir@apoenasoftwarelivre.com.br)
*	@version    PHP4
*/

/**
*	Estao declaradas aqui todas constantes utilizadas pelos graficos
*/

// Definicoes usadas por todos os graficos
define("GRA_EMPRESA", 	0 );
?>
