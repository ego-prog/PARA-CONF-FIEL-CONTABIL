<html>

<head>

<title>Sobre o FIEL Cont�bil...</title>

<script language="javascript">

function fechaJanela() {
	window.close();
}
</script>

<body bgcolor="#FFFFFF" text="#000000" link="#FFFFFF"
	  vlink="#FFFFFF" alink="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<center>
	<!-- T�tulo do FIEL Cont�bil -->
	<table width="80%" border="0" cellspacing"4" cellpadding="1" align="center">

	<tr>

		<td>
		 <div align="center"><img src="./imagens/contabil.jpg"></div><br>
		</td>

	</tr>

	<tr bgcolor="#669900">

		<td width="100%"><font face="Verdana" size="4" color="#FFFFFF">
		<center>
		 <strong>O FIEL Cont�bil � um sistema desenvolvido como parte integrante do Projeto FIEL</strong></center></font>
		</td>

	</tr>

	</table>

	<br>

	<table width="80%" border="0" cellspacing"4" cellpadding="1" align="center">

	<tr>

		<td>
		 <div align="center" valign="center"><img src="./imagens/fiel_corrente.jpg" border="0"><br>
		 <font face="Arial, Tahoma" size="+2" color="#669900">Liberte-se do <br>software propriet�rio
		 </font></div>
		</td>

	</tr>

	<tr bgcolor="#669900">

		<td width="100%"><font face="Verdana" size="4" color="#FFFFFF"><center>
		 <strong>Projeto Financiado por:</strong></center></font>
		</td>

	</tr>

	<tr bgcolor="#FFFFFF">

		<td width="100%" align="center">
		<a href="http://www.bancariospoa.com.br" target="blank"><img src="./imagens/bancariospoa.jpg" border="0"></a><br>
		</td>

	</tr>

	<tr bgcolor="#669900">

		<td width="100%"><font face="Verdana" size="4" color="#FFFFFF"><center>
		 <strong>Desenvolvimento:</strong></center></font>
		</td>

	</tr>

	<tr bgcolor="#FFFFFF">

		<td width="100%" align="center">
		<a href="http://www.apoenasoftwarelivre.com.br" target="blank"><img src="./imagens/apoena.jpg" width="150" border="0"></a>
		</td>

	</tr>

	</table>

	<!-- Ferramentas utilizadas para o Desenvolvimento do FIEL Cont�bil -->
	<br>
	<table width="50%" border="0" cellspacing"4" cellpadding="1" align="center">

	<tr bgcolor="#669900">

		<td width="100%"><font face="Verdana" size="2" color="#FFFFFF"><center>
		 <strong>Ferramentas Utilizadas:</strong></center></font>
		</td>

	</tr>

	</table>


	<table width="100%" border="0" align="center">

	<tr>
	  <td>		<center>
		<a href="http://www.gnu.org" target="blank"><img src="./imagens/cl_linux.gif" width="100"></a>
		<a href="http://www.apache.org" target="blank"><img src="./imagens/apache.gif" width="250"></a><br>
		<a href="http://www.php.net" target="blank"><img src="./imagens/php.gif" width="100"></a>
		<a href="http://www.postgresql.org" target="blank"><img src="./imagens/pgsql.jpg" width="200"></a>
		<a href="http://www.fpdf.org" target="blank"><img src="./imagens/fpdf.gif" width="100"></a>
		</center></td>

	</tr>

	</table>
	<p align="center">[<a href="javascript:fechaJanela()"><font color="blue" size="1" face="Verdana, Arial, Helvetica, sans-serif">
	Fechar</font></a>]</p><br>

</head>

</center>
</body>

</html>





